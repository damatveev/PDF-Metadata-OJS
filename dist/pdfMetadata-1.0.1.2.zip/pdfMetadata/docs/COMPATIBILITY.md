# Совместимость

Дата актуализации: 22 сентября 2026.

Повторная сверка исходников 24 сентября 2026 для 1.0.1.1: OJS `769450f2d4048da1f5bcf7f9537f51f7c2c2234b` (3.5.0.5), lib/pkp `6acb1be2eb8bde98545de595c3975861e923561e`, UI `1a7a47504c4f8b78f423cdfd16c55c0fcf01caca`. Это проверка контрактов исходников, не результат запуска полного OJS.

Целевая линия: **OJS 3.5.x**, минимально **3.5.0-4** для custom plugin API endpoint.

Версия, на которой сверялась интеграция при разработке 1.0.1: **OJS 3.5.0-5**.

## Используемые модели OJS 3.5

Publication:

- multilingual title/subtitle/abstract;
- keywords;
- citationsRaw;
- DOI relation;
- OJS-specific sectionId, issueId, pages.

Author:

- multilingual givenName/familyName/preferredPublicName;
- email;
- ORCID;
- country;
- url;
- userGroupId;
- includeInBrowse.

Affiliation:

- multilingual name;
- ROR;
- author relation.

Workspace 1.0.1 хранит review draft в этой логике, но до отдельной команды импорта не создаёт соответствующие DB entities.

## Проверенные интеграционные точки

- `APIHandler::endpoints::plugin` с сигнатурой callback `(string $hookName, APIRouter $apiRouter)` для OJS 3.5.0-4+;
- явная регистрация plugin locale path до разрешения display name/labels;

- GenericPlugin registration;
- plugin API controller registration;
- backend TemplateManager assets;
- context-scoped sections;
- author user groups;
- publication/author/affiliation repositories и validators для legacy apply mode;
- private file handling;
- OJS session + CSRF.

## Runtime

Требуется:

- PHP 8.2+ в рамках требований OJS 3.5;
- `mbstring`;
- DOM/libxml;
- Linux;
- Poppler;
- `prlimit`.

## Не заявляется

Плагин не заявляет совместимость с OJS 3.3, 3.4, будущей 3.6 без отдельного audit, а также с OMP/OPS.

При каждом maintenance upgrade OJS 3.5 необходимо повторно проверить:

1. plugin routing;
2. role middleware;
3. context and session behavior;
4. schema names;
5. repositories/validators;
6. TemplateManager backend asset loading.
