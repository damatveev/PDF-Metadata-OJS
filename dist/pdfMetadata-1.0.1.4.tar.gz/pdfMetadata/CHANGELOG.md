# Changelog

## 1.0.1.4 — 2026-09-24

- Исправлена авторизация standalone workspace по штатной схеме OJS 3.5: `has.user` + `has.context` + `has.roles`.
- Добавлены `UserRolesRequiredPolicy`, `ContextRequiredPolicy` и `ContextAccessPolicy`, как в core API OJS 3.5.
- Доступ к workspace разрешён site administrator, journal manager и sub-editor.
- Site administrator теперь получает интерфейс workspace в backend журнала.
- Повышен z-index launcher и добавлен явный `pointer-events`, чтобы кнопка «Разметить PDF выпуска» не перекрывалась backend-слоями OJS.

## 1.0.1.3 — 2026-09-24

- Добавлен fallback на Ghostscript, если `pdfinfo`/`pdftotext` (Poppler) недоступны на сервере.
- Ghostscript использует `txtwrite` для извлечения текста и `pdfpagecount` для определения числа страниц.
- Poppler остаётся приоритетным backend, если оба его бинарника доступны.
- Ghostscript запускается без shell, с `-dSAFER` и теми же ограничениями `prlimit`.
- Добавлен contract-test выбора PDF backend.

## 1.0.1.2 — 2026-09-24

- Исправлена регистрация custom API controller для OJS 3.5.0-4+: hook получает `APIRouter` напрямую, а не массив аргументов.
- Исправлена ошибка `api.404.endpointNotFound` для маршрута `/api/v1/pdf-metadata`.
- Локализации en/ru/ru_RU регистрируются до первого вызова `__()`; устранён вывод `##plugins.generic.pdfMetadata.*##`.
- Каталоги gettext нормализованы стандартными PO-заголовками.
- Добавлен статический contract-test сигнатуры OJS 3.5 API hook и регистрации locale.
- Минимальная поддерживаемая версия для custom endpoint: OJS 3.5.0-4.


## 1.0.1.1 — 2026-09-24

- Восстановлена панель submission без потери workspace полного выпуска.
- Исправлены запуск UI из head, исчезающие сообщения, переносы строк keywords/authors и JSON-массив разделов.
- Добавлены редактирование сохранённой разметки, очистка workspace с подтверждением и показ найденных организаций.
- Workspace операции сериализуются между запросами; проверяется фактический размер JSON, ограничен размер хранилища разметки.
- Добавлены недостающие переводы en/ru/ru_RU, проверки DOM/fetch и файлового workspace.
- Добавлена воспроизводимая сборка tar.gz/ZIP из отдельного репозитория.

Полная приёмка на работающем OJS/Linux остаётся отдельным этапом; локальные тесты не заменяют DB/browser интеграцию.

## 1.0.1 — 2026-09-22

### Added

- standalone workspace для загрузки полного PDF выпуска вне Submission;
- ручной выбор startPage/endPage для каждой статьи;
- извлечение метаданных только из выбранного диапазона;
- OJS-oriented review draft: Publication, Author, Affiliation;
- сохранение нескольких размеченных статей;
- статусы readyForOjs / needs review;
- экспорт черновиков workspace в JSON;
- русский и английский интерфейс workspace;
- приватное хранение полного PDF в temp_dir, привязанное к context/user/session.

### Changed

- для PDF полного выпуска XMP/PDF Info номера не подставляются как метаданные статьи;
- распознавание авторов стало консервативным: разделение given/family name требует редакторского подтверждения;
- frontend дополнен отдельной кнопкой «Разметить PDF выпуска» в backend OJS;
- версия плагина повышена до 1.0.1.

### Preserved

- режим извлечения/применения метаданных внутри уже существующего submission оставлен для обратной совместимости.

### Not included

- автоматическое создание submission;
- автоматическое назначение статьи выпуску;
- автоматическая публикация;
- OCR;
- физическое разрезание общего PDF на отдельные galley.

## 1.0.0.0

Первая версия: извлечение и проверка метаданных из PDF, уже связанного с существующим submission.
